----------------------------INSTRUCTIONS TO RUN A SINGLE INSTANCE---------------------------

For CP
|
.venv/bin/python3 Solution_command.py CP solver_name n_instance break_symmetry restart
|
|       recommended n_instance:     [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]
|       available solver_names:     [gecode, chuffed, highs]
|       available break_symmetry:   [load, dist, both, None]
|       available restart:          [True, False]
|
___________________________________________________________________________________________

For SAT
|
.venv/bin/python3 Solution_command.py SAT search_type n_instance break_symmetry
|
|       recommended n_instance:     [1,2,3,4,5,6,7,8,9,10]
|       available search_type:      [base, linear, binary]
|       available break_symmetry:   [load, None]
|
___________________________________________________________________________________________

For SMT
|
.venv/bin/python3 Solution_command.py SMT solver_name n_instance break_symmetry
|
|       recommended n_instance:     [1,2,3,4,5,6,7,8,9,10,13,16]
|       available search_type:      [z3_direct, z3, cvc5]
|       available break_symmetry:   [load, dist, both, None]    (Only available with solver_name=z3_direct)
|
___________________________________________________________________________________________

For MIP
|
.venv/bin/python3 Solution_command.py MIP solver_name n_instance break_symmetry
|
|       recommended n_instance:     [1,2,3,4,5,6,7,8,9,10,12,13,16,19]
|       available search_type:      [gurobi, cbc, xpres, copt, highs]
|       available break_symmetry:   [all, None]
|
___________________________________________________________________________________________



------------------------INSTRUCTIONS TO RUN EVERY PROPOSED INSTANCE------------------------

.venv/bin/python3 All_solutions_command.py

___________________________________________________________________________________________
