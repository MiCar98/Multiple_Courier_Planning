import sys, os
from Solving_Functions import *
from pathlib import Path

#COMMAND SYNTAX
#CP) Solution_command.py CP solver_name n_instance break_symmetry restart
#SAT) Solution_command.py SAT search_type n_instance break_symmetry
#SMT) Solution_command.py SMT solver_name n_instance break_symmetry
#MIP) Solution_command.py MIP solver_name n_instance break_symmetry


params ={
    'CP':{'solver_names':['gecode', 'chuffed', 'highs'], 'break_symmetry':['load', 'dist', 'both', 'None'], 'restart':['True', 'False']},
    'SAT':{'search_types':['base', 'linear', 'binary'], 'break_symmetry':['load', 'None']},
    'SMT':{'solver_names':['z3_direct', 'z3', 'cvc5'], 'break_symmetry':['load', 'dist', 'both','None']},
    'MIP':{'solver_names':['gurobi', 'cbc', 'highs', 'xpress', 'copt'], 'break_symmetry':['all', 'None']}
}

method = sys.argv[1]
if method not in ['CP', 'SAT', 'SMT' ,'MIP']:
    print("Unknown solution method")
    exit(-1)

if method in ['CP', 'SMT', 'MIP']:
    solver = sys.argv[2]
    if solver not in params[method]['solver_names']:
        print(f'{solver} is an unknown solver name for {method}')
        exit(-2)
else:
    search_type = sys.argv[2]
    if search_type not in params[method]['search_types']:
        print(f'{search_type} is an unknown search type for SAT')
        exit(-2)

N_inst = sys.argv[3]

break_symmetry = sys.argv[4]
if break_symmetry not in params[method]['break_symmetry']:
    print(f"{break_symmetry} is an unknown symmetry type for {method}, accepted values: {params[method]['break_symmetry']}")
    exit(-3)
if method == 'SMT' and solver != 'z3_direct':
    print(f'Only z3_direct supports symmetry breaking, the {break_symmetry} directive will be ignored')

if method == 'CP':
    restart = sys.argv[5]
    if restart not in params[method]['restart']:
        print('Restart can only be True or False')
    else:
        if restart=='True':
            restart = True
        else:
            restart=False


#Reading the instance from File
if int(N_inst)<10:
    inst_name="Instances/inst0"+N_inst+".dat"
else:
    inst_name="Instances/inst"+N_inst+".dat"

#Open instance .dat file
f = open(inst_name, 'r')

#Read number of couriers
m=int(f.readline())

#Read number of items
n=int(f.readline())

#Read courier capacities
l_split = f.readline().split()
l=[]
for i in l_split:
    l.append(int(i))

#Read item sizes
s_split = f.readline().split()
s=[]
for i in s_split:
    s.append(int(i))

#Read distance matrix
D = []
for i in range(n+1):
    d_split = f.readline().split()
    d_row = []
    for j in d_split:
        d_row.append(int(j))
    D.append(d_row)

#Starting from D compute Upper and Lower bound for the problem:
Dnp = np.array(D)
round_trips=[]
for i in range(n):
    round_trips.append(Dnp[i][n]+Dnp[n][i])
LB = max(round_trips)
LLB = min(round_trips)

UB = 0
for i in range(n+1):
    UB+=max(Dnp[i])


dict={}
try: 
    if method=="CP":
        dict=Solve_CP(m, n, l, s, Dnp, UB, LB, LLB, solver, break_symmetry, restart)
    elif method=="SAT":
        dict=Solve_SAT(m, n, l, s, Dnp, UB, LB, LLB, break_symmetry, search_type)
    elif method=="SMT":
        if solver == 'z3_direct':
            dict=Solve_SMT(m, n, l, s, D, UB, LB, break_symmetry)
        else:
            dict = Solve_SMT_multiple(m, n, l, s, D, UB, LB, solver)    
    elif method=="MIP":
        dict=Solve_MIP(m, n, l, s, Dnp, UB, LB, solver, break_symmetry)
    else:
        print("There is no such method")
except:
    dict=None

if dict is not None:
    print(dict)
    #Printing results on file
    keys = ['time', 'optimal', 'obj', 'sol']
    file_name = 'res/'+method+'/'+N_inst+'.json'
    path = Path(file_name)
    if path.is_file():
        f = open(file_name, 'r')
        f2 = open(file_name+'_2', 'w')
        bracket = f.readline()
        f2.write(bracket)
        f2.write("\""+dict['approach'] +"\":\n{")
        for k in keys:
            f2.write("\""+k+"\":"+str(dict[k]))
            if k !='sol':
                f2.write(',\n')
            else:
                f2.write('\n')
        f2.write("},\n")

        for line in f.readlines():
            f2.write(line)
        #f.flush()
        f.close()
        f2.close()
        os.remove(file_name)
        os.rename(file_name+'_2', file_name)

    else:
        f = open(file_name, 'x')
        f.write('{')
        f.write("\n\""+dict['approach'] +"\":\n{")
        for k in keys:
            if k=='time':
                f.write("\""+k+"\":"+str(min(300,dict[k])))
            else:
                f.write("\""+k+"\":"+str(dict[k]))
            if k !='sol':
                f.write(',\n')
            else:
                f.write('\n')
        f.write("}\n")
        f.write('}')
        #f.flush()
        f.close()


