from subprocess import run
import os, stat
configs = {
    'CP':{
        'instances':[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21],
        'keywords':[
            ['gecode', 'None', 'False'],
            ['chuffed', 'None', 'False'],
            ['highs', 'None', 'False'],
            ['gecode', 'dist', 'False'],
            ['gecode', 'None', 'True'],
            ['gecode', 'dist', 'True']            
        ]
    },
    'SAT':{
        'instances':[1,2,3,4,5,6,7,8,9,10],
        'keywords':[
            ['base', 'None'],
            ['linear', 'None'],
            ['binary', 'None'],
            ['base', 'load']         
        ]
    },
    'SMT':{
        'instances':[1,2,3,4,5,6,7,8,9,10,13,16,19],
        'keywords':[
            ['z3_direct', 'None'],
            ['z3_direct', 'dist'],
            ['z3_direct', 'load'],
            ['z3_direct', 'both'],  
            ['z3', 'None'],
            ['cvc5', 'None']         
        ]  
    },
    'MIP':{
        'instances':[1,2,3,4,5,6,7,8,9,10,11,12,13,16,19],
        'keywords':[
            ['gurobi', 'None'],
            ['gurobi', 'all'],
            ['copt', 'None'],
            ['copt', 'all'],
            ['cbc', 'None'],
            ['cbc', 'all'],         
        ]  
    }

}
import os
import subprocess

# Ensure writable temp directory for caches
tmp_dir = os.path.join(os.getcwd(), "tmp_cache")
os.environ["TMPDIR"] = tmp_dir
os.makedirs(tmp_dir, exist_ok=True)

# Main execution loop
for method in configs.keys():
    for n in configs[method]['instances']:
        for kw in range(len(configs[method]['keywords'])):
            args = [os.path.join(os.getcwd(), "Solution_command.py")]
            args.append(method)
            args.append(configs[method]['keywords'][kw][0])
            args.append(str(n))
            args += configs[method]['keywords'][kw][1:]

            # Ensure working directory is writable
            working_dir = os.getcwd()
            if not os.access(working_dir, os.W_OK):
                raise PermissionError(f"Working directory {working_dir} is not writable")

            print(f"Running: {args} inside {working_dir}")

            try:
                res = subprocess.run(
                    ["python3"] + args,  # Explicitly call Python
                    timeout=300,
                    check=True,
                    capture_output=True,
                    text=True,
                    cwd=working_dir
                )
                print(f"STDOUT: {res.stdout}")

            except subprocess.CalledProcessError as e:
                print(f"Command failed with error: {e.stderr}")
            except PermissionError as e:
                print(f"Permission error: {e}")
